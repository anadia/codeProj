﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DemoLinQ.Clases
{
    public enum Departamento
    {
        Marketing,
        RecursosHumanos,
        Administracion,
        Ventas
    }
}

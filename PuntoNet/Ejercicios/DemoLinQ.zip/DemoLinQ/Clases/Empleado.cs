﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DemoLinQ.Clases
{
    public class Empleado
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public Departamento Departamento { get; set; }
        public DateTime FechaIncorporacion { get; set; }
        public int EmpresaId { get; set; }

        public static List<Empleado> ObtenerEmpleados()
        {
            return new List<Empleado>
            {
                new Empleado { Id= 1, Nombre = "Empleado1", EmpresaId = 1, FechaIncorporacion = new DateTime(2015, 5, 1), Departamento = Departamento.Administracion},
                new Empleado { Id= 2, Nombre = "Empleado2", EmpresaId = 2, FechaIncorporacion = new DateTime(2016, 6, 1), Departamento = Departamento.Marketing},
                new Empleado { Id= 3, Nombre = "Empleado3", EmpresaId = 3, FechaIncorporacion = new DateTime(2017, 7, 1), Departamento = Departamento.RecursosHumanos},
                new Empleado { Id= 4, Nombre = "Empleado4", EmpresaId = 4, FechaIncorporacion = new DateTime(2018, 8, 1), Departamento = Departamento.Ventas},
                new Empleado { Id= 5, Nombre = "Empleado5", EmpresaId = 5, FechaIncorporacion = new DateTime(2019, 9, 1), Departamento = Departamento.RecursosHumanos},
                new Empleado { Id= 6, Nombre = "Empleado6", EmpresaId = 1, FechaIncorporacion = new DateTime(2015, 5, 1), Departamento = Departamento.Ventas},
                new Empleado { Id= 7, Nombre = "Empleado7", EmpresaId = 1, FechaIncorporacion = new DateTime(2015, 5, 1), Departamento = Departamento.Ventas},
                new Empleado { Id= 8, Nombre = "Empleado8", EmpresaId = 1, FechaIncorporacion = new DateTime(2015, 5, 1), Departamento = Departamento.Ventas},
                new Empleado { Id= 9, Nombre = "Empleado9", EmpresaId = 1, FechaIncorporacion = new DateTime(2015, 5, 1), Departamento = Departamento.Ventas},
                new Empleado { Id= 10, Nombre = "Empleado10", EmpresaId = 1, FechaIncorporacion = new DateTime(2015, 5, 1), Departamento = Departamento.Ventas},
                new Empleado { Id= 11, Nombre = "Empleado11", EmpresaId = 1, FechaIncorporacion = new DateTime(2015, 5, 1), Departamento = Departamento.Ventas},
                new Empleado { Id= 12, Nombre = "Empleado12", EmpresaId = 1, FechaIncorporacion = new DateTime(2015, 5, 1), Departamento = Departamento.Ventas},
                new Empleado { Id= 13, Nombre = "Empleado13", EmpresaId = 1, FechaIncorporacion = new DateTime(2015, 5, 1), Departamento = Departamento.Ventas}
            };
        }
    }
}

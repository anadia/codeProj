﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DemoLinQ.Clases
{
    public class Empresa
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string CIF { get; set; }

        public static List<Empresa> ObtenerEmpresas()
        {
            return new List<Empresa>
            {
                new Empresa { Id = 1, Nombre = "Empresa1", CIF = "A111111"},
                new Empresa { Id = 2, Nombre = "Empresa2", CIF = "A222222"},
                new Empresa { Id = 3, Nombre = "Empresa3", CIF = "A333333"},
                new Empresa { Id = 4, Nombre = "Empresa4", CIF = "A444444"},
                new Empresa { Id = 5, Nombre = "Empresa5", CIF = "A555555"}

            };
        }
    }
}

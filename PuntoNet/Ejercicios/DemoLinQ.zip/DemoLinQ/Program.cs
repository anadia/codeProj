﻿using DemoLinQ.Clases;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DemoLinQ
{
    class Program
    {
        static void Main(string[] args)
        {
            var empleados = Empleado.ObtenerEmpleados();
            var empresas = Empresa.ObtenerEmpresas();

            /*--------------------------------*/
            var TodosLosEmpleados = ObtenerTodosEmpleados(empleados);

            foreach (var empleado in TodosLosEmpleados)
            {
                Console.WriteLine(empleado.Nombre);
            }
            /*--------------------------------*/

            //Get By Id que exista
            var empleadoPorId = ObtenerEmpleadoById(empleados, 1);

            Console.WriteLine(empleadoPorId.Nombre);

            //Get By Id que no exista
            var empleadoPorId2 = ObtenerEmpleadoById(empleados, 100);

            Console.WriteLine(empleadoPorId2.Nombre);

            /*--------------------------------*/

            var empleadosPorNombre = ObtenerEmpleadoPorNombre(empleados, "do1");

            foreach (var empleado in empleadosPorNombre)
            {
                Console.WriteLine(empleado.Nombre);
            }

            /*--------------------------------*/

            var empleadosPorNombreDeEmpresa = ObtenerEmpleadosPorNombreDeEmpresa(empleados, empresas, "sa1");

            foreach (var empleado in empleadosPorNombreDeEmpresa)
            {
                Console.WriteLine(empleado.Nombre);
            }

            /*--------------------------------*/

            var empleadosPorNombreDeEmpresaPaginado = ObtenerEmpleadosPorNombreDeEmpresaPaginado(empleados, empresas, "sa1", 1, 4);

            foreach (var empleado in empleadosPorNombreDeEmpresaPaginado)
            {
                Console.WriteLine("Pagina1: " + empleado.Nombre);
            }

            var empleadosPorNombreDeEmpresaPaginado2 = ObtenerEmpleadosPorNombreDeEmpresaPaginado(empleados, empresas, "sa1", 2, 4);

            foreach (var empleado in empleadosPorNombreDeEmpresaPaginado2)
            {
                Console.WriteLine("Pagina2: " + empleado.Nombre);
            }
        }

        /// <summary>
        /// Get All empleados
        /// </summary>
        /// <param name="empleados"></param>
        /// <returns></returns>
        static List<Empleado> ObtenerTodosEmpleados(List<Empleado> empleados)
        {
            var resultado = empleados.ToList();

            return resultado;
        }

        /// <summary>
        /// Get by Id
        /// </summary>
        /// <param name="empleados"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        static Empleado ObtenerEmpleadoById(List<Empleado> empleados, int id)
        {
            var resultado = empleados.Where(e => e.Id == id).FirstOrDefault();

            if(resultado == null)
            {
                resultado = new Empleado();
            }

            return resultado;
        }

        /// <summary>
        /// Get por nombre y ordenado
        /// </summary>
        /// <param name="empleados"></param>
        /// <param name="nombre"></param>
        /// <returns></returns>
        static List<Empleado> ObtenerEmpleadoPorNombre(List<Empleado> empleados, string nombre)
        {
            var resultado = empleados.Where(e => e.Nombre.Contains(nombre)).OrderBy(e => e.Nombre).ToList();


            return resultado;
        }

        /// <summary>
        /// Get por nombre de empresa y ordenado
        /// </summary>
        /// <param name="empleados"></param>
        /// <param name="nombre"></param>
        /// <returns></returns>
        static List<Empleado> ObtenerEmpleadosPorNombreDeEmpresa(List<Empleado> empleados, List<Empresa> empresas, string nombreEmpresa)
        {
            var resultado = from e in empleados
                            join em in empresas on e.EmpresaId equals em.Id
                            where em.Nombre.Contains(nombreEmpresa)
                            select e;


            return resultado.ToList();
        }

        /// <summary>
        /// Get por nombre de empresa y ordenado paginado
        /// </summary>
        /// <param name="empleados"></param>
        /// <param name="nombre"></param>
        /// <returns></returns>
        static List<Empleado> ObtenerEmpleadosPorNombreDeEmpresaPaginado(List<Empleado> empleados, 
                                                                         List<Empresa> empresas, 
                                                                         string nombreEmpresa, 
                                                                         int numPagina, 
                                                                         int numElementos)
        {
            var resultado = from e in empleados
                                             join em in empresas on e.EmpresaId equals em.Id
                                             where em.Nombre.Contains(nombreEmpresa)
                                             select e;


            return resultado.Skip(numElementos*(numPagina-1)).Take(numElementos).ToList();
        }
    }
}

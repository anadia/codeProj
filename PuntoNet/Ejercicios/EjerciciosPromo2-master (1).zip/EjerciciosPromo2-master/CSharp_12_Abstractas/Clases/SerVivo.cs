﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharp_12_Abstractas
{
    public class SerVivo
    {
        public bool EstaVivo { get; set; } = true;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharp_11_Herencia
{
    public class Bicicleta : DePasajeros
    {
        public int Velocidades { get; set; }
    }
}

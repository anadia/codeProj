﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharp_11_Herencia
{
    public class DePasajeros : Vehiculo
    {
        public int NumeroPasajeros { get; set; }
    }
}

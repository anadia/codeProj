﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharp_11_Herencia
{
    public class Vehiculo
    {
        public int Matricula { get; set; }
    }
}

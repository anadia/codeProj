﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharp_13_Interfaces
{
    public abstract class Persona
    {
        public string Nombre { get; set; }

        public abstract void SerFeliz();
    }
}
